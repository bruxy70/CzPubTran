# CzPubTran
Calling CHAPS REST API to get information about public transit in CZ
